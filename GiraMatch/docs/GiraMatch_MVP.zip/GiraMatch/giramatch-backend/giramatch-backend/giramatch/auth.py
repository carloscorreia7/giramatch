"""Senhas e sessões (token Bearer)."""
import hashlib
import hmac
import secrets
from datetime import datetime, timedelta, timezone

from . import config
from .db import agora

ITERACOES = 200_000


def gerar_hash(senha: str) -> str:
    sal = secrets.token_hex(16)
    dk = hashlib.pbkdf2_hmac("sha256", senha.encode(), bytes.fromhex(sal), ITERACOES)
    return f"pbkdf2_sha256${ITERACOES}${sal}${dk.hex()}"


def verificar_senha(senha: str, armazenado: str) -> bool:
    try:
        _, iteracoes, sal, esperado = armazenado.split("$")
        dk = hashlib.pbkdf2_hmac("sha256", senha.encode(), bytes.fromhex(sal), int(iteracoes))
        return hmac.compare_digest(dk.hex(), esperado)
    except (ValueError, TypeError):
        return False


def criar_sessao(conn, usuario_id: int) -> dict:
    token = secrets.token_urlsafe(32)
    expira = (datetime.now(timezone.utc) + timedelta(hours=config.TOKEN_HORAS)).replace(microsecond=0)
    conn.execute(
        "INSERT INTO sessoes (token, usuario_id, criada_em, expira_em) VALUES (?, ?, ?, ?)",
        (token, usuario_id, agora(), expira.isoformat()),
    )
    return {"token": token, "expira_em": expira.isoformat()}


def usuario_do_token(conn, token: str):
    row = conn.execute(
        """SELECT u.id, u.nome, u.email, u.perfil, u.orgao_id, s.expira_em
             FROM sessoes s JOIN usuarios u ON u.id = s.usuario_id
            WHERE s.token = ?""",
        (token,),
    ).fetchone()
    if row is None:
        return None
    if datetime.fromisoformat(row["expira_em"]) < datetime.now(timezone.utc):
        conn.execute("DELETE FROM sessoes WHERE token = ?", (token,))
        return None
    return dict(row)


def encerrar_sessao(conn, token: str) -> None:
    conn.execute("DELETE FROM sessoes WHERE token = ?", (token,))
