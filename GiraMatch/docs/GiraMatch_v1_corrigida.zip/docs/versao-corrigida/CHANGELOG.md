# CHANGELOG — v1-corrigida (a partir de v0-auditada `27d941d`)

## Corrigido
- **F-001** `giramatch/api.py`: `conectar()` agora fica dentro de `try`. Se o banco não abre, a API responde **503** com mensagem genérica e só registra o **tipo** do erro (não a mensagem, que pode conter endereço/credenciais).
- **F-003** `giramatch/auth.py`, `api.py`, `config.py`: limite de tentativas de login. 8 falhas (mesmo IP + e-mail) em 5 min → **429**, mesmo com a senha certa; limite extra de 30 por IP; login válido zera o contador do par. Configurável por `GIRAMATCH_LOGIN_MAX_FALHAS`, `GIRAMATCH_LOGIN_MAX_FALHAS_IP`, `GIRAMATCH_LOGIN_JANELA_S`.
- **F-006** `giramatch/api.py`: o log do servidor passou a registrar só `MÉTODO /caminho -> status`, sem IP e sem parâmetros de URL (verificado em execução).
- **F-004 (parcial)** `giramatch/__main__.py`: aviso na subida quando o banco é PostgreSQL e `GIRAMATCH_CORS=*`.
- **F-009** `DOCUMENTACAO.md`: banco SQLite **ou** PostgreSQL, modo demonstração e link para a seção de publicação.

## Testes
- `tests/test_auditoria.py`: teste de banco indisponível deixou de ser `xfail` e passou a verificar 503 genérico; teste "sem limite de login" substituído por 2 testes de bloqueio.
- `tests/conftest.py` (novo): zera o contador de login antes de cada teste.
- Resultado: **28 passed** (antes: 26 passed + 1 xfailed).

## Artefatos
- README do backend (segurança do login, variáveis), `.env.exemplo`, as-built (`KNOWN_ISSUES`, `SETUP`, `TEST_PLAN`), `TESTS.md`, `HARNESS.md`, PNG da arquitetura e apresentação (contagem de testes e menção ao 429/503).

## Não alterado
Front-end (`index.html`, `app.js`, páginas), `render.yaml`, esquema do banco, regras do match. Nenhum teste foi desativado e nenhum requisito foi alterado.
